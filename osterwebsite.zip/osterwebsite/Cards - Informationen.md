# Osterbräuche

#### 

#### Ostereiersuche



Ein spielerischer Brauch, bei dem Kinder am Ostersonntag versteckte Süßigkeiten und bunt bemalte Eier im Garten oder Haus suchen

#### 

#### Osterfeuer



Ein geselliges Brauchtumsfeuer am Karsamstag oder Ostersonntag, das symbolisch den Winter vertreibt und das Licht der Auferstehung feiert

#### 

#### Palmbuschen



Gebundene Zweige aus Weidenkätzchen und Buchsbaum, die am Palmsonntag gesegnet werden, um an den Einzug Jesu in Jerusalem zu erinnern

#### 

#### Osterkorb



Ein mit Speisen gefüllter Korb, der zur Fleischweihe in die Kirche gebracht und anschließend beim Osterfrühstück verzehrt wird

#### 

#### Ratschen



Holzinstrumente, die von Kindern bedient werden, um während der Kartage das „Schweigen der Kirchenglocken“ lautstark zu ersetzen

#### 

#### Ostermarkt



Ein Markt in der Fastenzeit, auf dem traditionelles Kunsthandwerk, regionale Spezialitäten und Osterdekoration angeboten werden

#### 

#### \----------------------------------------

#### 

# Osterdeko

#### 

#### bemalte Eier



Ausgeblasene oder hartgekochte Eier, die als Symbol des Lebens bunt verziert und oft an Frühlingszweige gehängt werden

#### 

#### Osterkranz



Ein dekoratives Geflecht aus Zweigen oder Blumen, das als Türkranz oder Tischschmuck die Osterzeit einläutet

#### 

#### Frühlingsblumen



Typische Frühblüher wie Tulpen, Narzissen und Hyazinthen, die frische Farben und Lebensfreude in die Dekoration bringen

#### 

#### Tischdeko



Eine festliche Gestaltung der Tafel mit Servietten, Streudeko und Kerzen für das gemeinsame Osteressen im Kreise der Familie

#### 

#### Fensterbilder



Farbenfrohe Motive aus Papier oder Kreidemarkern, die Fenster passend zur Jahreszeit mit Hasen- oder Blumenmotiven verschönern.

#### 

#### DIY-Osterhasen



Selbstgebastelte Hasenfiguren aus Materialien wie Holz, Filz oder Eierkartons, die eine persönliche Note in die Deko bringen

#### 

#### \----------------------------------------

#### 

# Osterrezepte

#### 

#### Osterpinze



Ein traditionelles, leicht süßes Hefegebäck aus der Steiermark, das typischerweise dreifach eingeschnitten und zur Osterjause serviert wird

#### 

#### Karottenkuchen



Ein besonders saftiger Rührkuchen mit geraspelten Möhren und Nüssen, der klassisch mit Marzipanrüebli verziert wird

#### 

#### Eierlikör-Dessert



Cremige Nachspeisen, die durch den Zusatz von Eierlikör eine besonders feine, gelbe Note und ein intensives Aroma erhalten

#### 

#### Hefezopf



Ein aus drei Strängen geflochtenes Gebäck aus süßem Hefeteig, das oft mit Hagelzucker oder Mandelblättchen bestreut wird

#### 

#### Osterkekse



Mürbeteigplätzchen in Form von Hasen, Küken oder Eiern, die nach dem Backen bunt mit Zuckerguss verziert werden

#### 

#### Brunch-Ideen



Eine Kombination aus Frühstück und Mittagessen mit herzhaften Eiergerichten, Aufstrichen und süßem Gebäck für einen entspannten Ostermorgen



